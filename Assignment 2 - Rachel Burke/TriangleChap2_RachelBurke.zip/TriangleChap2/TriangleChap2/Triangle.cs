﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriangleChap2
{
    public class Triangle
    {
        //Defining three sides of a triangle
        private int sideA { get; set; }
        private int sideB { get; set; }
        private int sideC { get; set; }

        //Defining triangle
        public Triangle (int SideA, int SideB, int SideC)
        {
            sideA = SideA;
            sideB = SideB;
            sideC = SideC;
        }

        //Tells whether or not a triangle is isosceles
        public static bool Isosceles (Triangle triangle)
        {
            if (triangle.sideA == triangle.sideB)
            {
                return true;
            }
            else if (triangle.sideB == triangle.sideC)
            {
                return true;
            }
            else if (triangle.sideA == triangle.sideC)
            {
                return true;
            }
            return false;
        }

        //Tells whether or not a triangle is equilateral
        public static bool Equilateral (Triangle triangle)
        {
            if (triangle.sideA == triangle.sideB)
            {
                if (triangle.sideB == triangle.sideC)
                {
                    return true;
                }
                return false;
            }
            return false;
        }

        //Tells whether or not a tringle is scalene
        public static bool Scalene (Triangle triangle)
        {
            if(triangle.sideA != triangle.sideB)
            {
                if (triangle.sideB != triangle.sideC)
                {
                    if (triangle.sideA != triangle.sideC)
                    {
                        return true;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }

        //Simple Version Conditions c1-c3
        public static bool SimpleTestRange (Triangle triangle)
        {
            //c1
            if (triangle.sideA < 1 || triangle.sideA > 200)
            {
                return false;
            }
            //c2
            if (triangle.sideB < 1 || triangle.sideB > 200)
            {
                return false;
            }
            //c3
            if (triangle.sideC < 1 || triangle.sideC > 200)
            {
                return false;
            }
            return true;
        }

        //Simple Version Conditions c4-c6
        public static bool SimpleVersionCheck (Triangle triangle)
        {
            //c4
            if (triangle.sideA >= triangle.sideB + triangle.sideC)
            {
                return false;
            }
            //c5
            if (triangle.sideB >= triangle.sideA + triangle.sideC)
            {
                return false;
            }
            //c6
            if (triangle.sideC >= triangle.sideA + triangle.sideB)
            {
                return false;
            }
            return true;
        }
    }
}
