﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TriangleChap2
{
    public partial class TriangleChecker : Form
    {
        Triangle objTriangle;

        public TriangleChecker()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtA.Text = String.Empty;
            txtB.Text = String.Empty;
            txtC.Text = String.Empty;
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            try
            {
                objTriangle = new Triangle(int.Parse(txtA.Text), int.Parse(txtB.Text), int.Parse(txtC.Text));

                //Do we have valid numbers?
                if(Triangle.SimpleTestRange(objTriangle) == false)
                {
                    //Nope, display an error message.
                    MessageBox.Show("Please enter side values between 1 and 200, inclusive.", "Error!");
                }

                //Yes. Do we have a triangle?
                else if (Triangle.SimpleVersionCheck(objTriangle) == false)
                {
                    //Nope, display an error message.
                    MessageBox.Show("Not a triangle. Please enter numbers for a valid triangle.", "Error!");
                }

                //Yes. Is it equilateral?
                else if (Triangle.Equilateral(objTriangle) == true)
                {
                    //Yes, display the triangle type.
                    MessageBox.Show("This is an equilateral triangle.", "Congratualtions!");
                }

                //No. Is it scalene?
                else if (Triangle.Scalene(objTriangle) == true)
                {
                    //Yes, display the triangle type.
                    MessageBox.Show("This is a scalene triangle.", "Congratulations!");
                }

                //No. Is it isoceles?
                else if (Triangle.Isosceles(objTriangle) == true)
                {
                    //Yes, display the triangle type.
                    MessageBox.Show("This is an isoceles triangle.", "Congratualtions!");
                }

                //If we are still going, we have an error.
                else
                {
                    MessageBox.Show("Program error. All triangle types checked.", "Warning!");
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Warning!");
            }
        }
    }
}
