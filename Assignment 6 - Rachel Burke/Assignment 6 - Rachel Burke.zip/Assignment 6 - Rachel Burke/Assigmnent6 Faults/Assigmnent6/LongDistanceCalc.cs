﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigmnent6
{
    public partial class LongDistanceCalc : Form
    {
        public decimal rate;
        public decimal actualCost;
        public decimal callCost;
        public int minutes;

        public LongDistanceCalc()
        {
            InitializeComponent();

            //Tried to clear these on startup
            rbDaytime.Checked = false;
            rbEvening.Checked = false;
            rbOffPeak.Checked = false;
        }
        //Calculate cost of call and minutes to be given
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                minutes = int.Parse(txtMinutes.Text);
 
// FAULT 1 - WE ARE ALLOWING NEGATIVE MINUTES
/*
                //Must have more than 0 minutes
                if (minutes < 0)
                {
                    MessageBox.Show("Enter a positive number of minutes.", "Warning!");
                }
*/
                //Daytime Call
                if (rbDaytime.Checked == true && rbEvening.Checked == false && rbOffPeak.Checked == false)
                {
                    rate = 0.07m;
                    callCost = rate * minutes;
                    actualCost = callCost;

//FAULT 2 - Making calls of 5 minutes in length look like a customer error
                    //Too few minutes
                    if (minutes <= 5)
                    {
                        actualCost = rate * 5;
                        lstDisplay.Items.Add("The cost of your call would have been $" + callCost + "," +
                            " but we charge a minimum Daytime Call cost of $" + actualCost + ","
                            + " so we will charge you accordingly.");
                        lblActualCost.Text = Math.Round(actualCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(callCost, 2).ToString();
                        lblMinutesGiven.Text = Convert.ToString(5) + " minutes";
                    }
                    //Too many minutes
                    else if (minutes > 30)
                    {
                        actualCost = rate * 30;
                        lstDisplay.Items.Add("The cost of your call would have been $" + callCost + "," +
                            " but we charge a maximum Daytime Call cost of $" + actualCost + ","
                            + " so we will charge you accordingly.");
                        lblActualCost.Text = Math.Round(actualCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(callCost, 2).ToString();
                        lblMinutesGiven.Text = Convert.ToString(30) + " minutes";

                    }
                    //Good number of minutes
                    else
                    {
                        lstDisplay.Items.Add("The cost of your Daytime Call was $" + actualCost + ".");
                        lblActualCost.Text = Math.Round(actualCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(callCost, 2).ToString();
                        lblMinutesGiven.Text = minutes.ToString() + " minutes";
                    }

                }
                //Evening Call
                else if (rbDaytime.Checked == false && rbEvening.Checked == true && rbOffPeak.Checked == false)
                {
                    rate = 0.12m;
                    callCost = rate * minutes;
                    actualCost = callCost;

//FAULT 3 - Displaying incorrect evening call costs for call costs less than 5 minutes
                    //Too few minutes
                    if (minutes < 5)
                    {
                        actualCost = rate * 5;
                        lstDisplay.Items.Add("The cost of your call would have been $" + actualCost + "," +
                            " but we charge a minimum Evening Call cost of $" + callCost + ","
                            + " so we will charge you accordingly.");
                        lblActualCost.Text = Math.Round(callCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(actualCost, 2).ToString();
                        lblMinutesGiven.Text = Convert.ToString(5) + " minutes";
                    }
                    //Too many minutes
                    else if (minutes > 30)
                    {
                        actualCost = rate * 30;
                        lstDisplay.Items.Add("The cost of your call would have been $" + callCost + "," +
                           " but we charge a maximum Evening Call cost of $" + actualCost + ","
                           + " so we will charge you accordingly and stop your call after 30 minutes.");
                        lblActualCost.Text = Math.Round(actualCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(callCost, 2).ToString();
                        lblMinutesGiven.Text = Convert.ToString(30) + " minutes";
                    }
                    //Given good minutes
                    else
                    {
                        lstDisplay.Items.Add("The cost of your Evening Call was $" + actualCost + ".");
                        lblActualCost.Text = Math.Round(actualCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(callCost, 2).ToString();
                        lblMinutesGiven.Text = minutes.ToString() + " minutes";
                    }
                }
                //Off-Peak Call
                else if (rbDaytime.Checked == false && rbEvening.Checked == false && rbOffPeak.Checked == true)
                {
                    rate = 0.05m;
                    callCost = rate * minutes;
                    actualCost = callCost;

                    //Too few minutes
                    if (minutes < 5)
                    {
                        actualCost = rate * 5;
                        lstDisplay.Items.Add("The cost of your call would have been $" + callCost + "," +
                            " but we charge a minimum Off-Peak Call cost of $" + actualCost + ","
                            + " so we will charge you accordingly.");
                        lblActualCost.Text = Math.Round(actualCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(callCost, 2).ToString();
                        lblMinutesGiven.Text = Convert.ToString(5) + " minutes";
                    }
                    //Too many minutes
                    else if (minutes > 30)
                    {
                        actualCost = rate * 30;
                        lstDisplay.Items.Add("The cost of your call would have been $" + callCost + "," +
                           " but we charge a maximum Off-Peak Call cost of $" + actualCost + ","
                           + " so we will charge you accordingly.");
                        lblActualCost.Text = Math.Round(actualCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(callCost, 2).ToString();
                        lblMinutesGiven.Text = Convert.ToString(30) + " minutes";
                    }
                    //We were given good minutes
                    else
                    {
                        lstDisplay.Items.Add("The cost of your Off-Peak Call was $" + actualCost + ".");
                        lblActualCost.Text = Math.Round(actualCost, 2).ToString();
                        lblTotalCost.Text = Math.Round(callCost, 2).ToString();
                        lblMinutesGiven.Text = minutes.ToString() + " minutes";
                    }
                }
                    //Clearing radio buttons and minutes text box
                    rbDaytime.Checked = false;
                    rbEvening.Checked = false;
                    rbOffPeak.Checked = false;
                    txtMinutes.Text = String.Empty;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Warning!");
            }
        }
        //Clear
        private void btnClear_Click(object sender, EventArgs e)
        {
            rbDaytime.Checked = false;
            rbEvening.Checked = false;
            rbOffPeak.Checked = false;
            txtMinutes.Text = String.Empty;
            lstDisplay.Items.Clear();
            lblActualCost.Text = String.Empty;
            lblMinutesGiven.Text = String.Empty;
            lblTotalCost.Text = String.Empty;
        }

        //Exit
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
