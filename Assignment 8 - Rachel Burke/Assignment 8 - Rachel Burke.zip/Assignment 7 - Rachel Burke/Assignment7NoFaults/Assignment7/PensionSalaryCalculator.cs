﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment7
{
    public partial class PensionSalaryCalculator : Form
    {

        DateTime startDate = new DateTime(2010, 6, 11);
        public PensionSalaryCalculator()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            DateTime date = dtpDateFiled.Value;
            int age = int.Parse(txtAge.Text);
            decimal salary = decimal.Parse(txtSalary.Text);
            int yearsWorked = int.Parse(txtYearsWorked.Text);
            int totalYears = age + yearsWorked;
            decimal projectedSalary;

            if(age <= 0)
            {
                MessageBox.Show("Please enter a postitive age.", "Warning!");
            }

            if (salary <= 0)
            {
                MessageBox.Show("Please enter a postitive salary.", "Warning!");
            }

            if (age <= 0)
            {
                MessageBox.Show("Please enter a postitive number of years worked.", "Warning!");
            }
            else
            {
                try
                {
                    //Date Check
                    int result = DateTime.Compare(startDate, date);
                    //Date After 6/11/2010
                    if (result < 0)
                    {
                        projectedSalary = salary;
                        lblProjSalary.Text = "$" + projectedSalary.ToString();
                    }
                    //Date On or Before 6/11/2010
                    else
                    {
                        //Age is less than retirement age
                        if (age < 63)
                        {
                            //Sum of 80 Check
                           if (totalYears < 80)
                            {
                                projectedSalary = salary;
                                lblProjSalary.Text = "$" + projectedSalary.ToString();
                            }
                           //80 Years Met
                            else
                            {
                                //Salary is up to $90,000
                                if (salary <= 90000)
                                {
                                    projectedSalary = 1.55m * salary;
                                    lblProjSalary.Text = "$" + projectedSalary.ToString();
                                }
                                //Salary is over $90,000
                                else
                                {
                                    projectedSalary = (1.55m * 90000) + ((salary - 90000) * 1.5m);
                                    lblProjSalary.Text = "$" + projectedSalary.ToString();
                                }
                            }
                        }
                        // Is retirement age
                        else
                        {
                            //Salary is up to $90,000
                            if (salary <= 90000)
                            {
                                projectedSalary = 1.6m * salary;
                                lblProjSalary.Text = "$" + projectedSalary.ToString();
                            }
                            //Salary is over $90,000
                            else
                            {
                                projectedSalary = (1.6m * 90000) + ((salary - 90000) * 1.5m);
                                lblProjSalary.Text = "$" + projectedSalary.ToString();
                            }
                        }
                    }
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message, "Warning!");
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            dtpDateFiled.Value = DateTimePicker.MinimumDateTime;
            txtAge.Text = String.Empty;
            txtSalary.Text = String.Empty;
            txtYearsWorked.Text = String.Empty;
            lblProjSalary.Text = String.Empty;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
